﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class Brick : MonoBehaviour {
//    private AudioSource brick;
//    void Start()
//    {
//        brick = GetComponent<AudioSource>();
//    }
//    void OnCollisionEnter2D(Collision2D obj)
//    {
//        if (obj.gameObject.tag == "Ball")
//        {
//            brick.Play();
 //           Destroy(gameObject);
 //       }
   // }
//}
